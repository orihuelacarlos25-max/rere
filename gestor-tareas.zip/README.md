# Gestor de Tareas ✅

Una pequeña aplicación en **React** para gestionar tareas.  
Incluye enrutamiento con **React Router**, manejo de formularios con **react-hook-form**, y efectos con **useEffect**.

---

## 🚀 Tecnologías usadas
- [React](https://react.dev/)
- [React Router DOM](https://reactrouter.com/)
- [React Hook Form](https://react-hook-form.com/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Vite](https://vitejs.dev/)

---

## 📂 Estructura del proyecto
```
src/
 ├── App.jsx
 ├── main.jsx
 ├── index.css
 ├── components/
 │    └── Navbar.jsx
 ├── pages/
 │    ├── HomePage.jsx
 │    ├── TareasPage.jsx
 │    ├── CrearTareaPage.jsx
 │    └── TareaDetallePage.jsx
```
---

## 📌 Funcionalidades
- **Enrutamiento** con React Router:
  - `/` → Página de inicio
  - `/tareas` → Lista de tareas (con datos simulados)
  - `/crear` → Formulario para crear tarea
  - `/tarea/:id` → Página de detalle de tarea
- **Formulario** con validación usando `react-hook-form`
- **useEffect** para:
  - Simular carga de datos con `setTimeout`
  - Actualizar el título de la página en cada vista

---

## ⚡ Cómo ejecutar el proyecto

1. Clona este repositorio o descarga el zip.
   ```bash
   git clone https://github.com/TU_USUARIO/gestor-tareas.git
   cd gestor-tareas
   ```

2. Instala las dependencias:
   ```bash
   npm install
   ```

3. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```

4. Abre en tu navegador:
   ```
   http://localhost:5173
   ```

---

## 📤 Subir a GitHub

1. Crea un nuevo repositorio en GitHub.
2. Inicializa git y sube el proyecto:
   ```bash
   git init
   git add .
   git commit -m "Gestor de Tareas con React Router, RHF y useEffect"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/gestor-tareas.git
   git push -u origin main
   ```

---

🎉
