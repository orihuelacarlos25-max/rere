import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function TareasPage() {
  const [tareas, setTareas] = useState([]);

  useEffect(() => {
    document.title = "Tareas - Gestor";
    setTimeout(() => {
      setTareas([
        { id: 1, titulo: "Aprender React Router" },
        { id: 2, titulo: "Practicar react-hook-form" },
        { id: 3, titulo: "Simular efectos con useEffect" },
      ]);
    }, 1000);
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">📋 Lista de Tareas</h1>
      {tareas.length === 0 ? (
        <p className="text-gray-500 mt-2">Cargando tareas...</p>
      ) : (
        <ul className="list-disc pl-6 mt-2">
          {tareas.map((tarea) => (
            <li key={tarea.id}>
              <Link to={`/tarea/${tarea.id}`} className="text-blue-600 underline">
                {tarea.titulo}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
