import { useParams, Link } from "react-router-dom";
import { useEffect } from "react";

export default function TareaDetallePage() {
  const { id } = useParams();

  useEffect(() => {
    document.title = `Detalle de Tarea ${id}`;
  }, [id]);

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Detalles de la Tarea</h1>
      <p className="mt-2">📌 Tarea con ID: {id}</p>
      <Link to="/tareas" className="mt-4 block text-blue-600 underline">
        ⬅ Volver a la lista
      </Link>
    </div>
  );
}
