import { Link } from "react-router-dom";
import { useEffect } from "react";

export default function HomePage() {
  useEffect(() => {
    document.title = "Inicio - Gestor de Tareas";
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Bienvenido al Gestor de Tareas ✅</h1>
      <p className="mt-2">Organiza tus pendientes fácilmente.</p>
      <Link to="/tareas" className="text-blue-600 underline mt-4 block">
        Ver mis tareas
      </Link>
    </div>
  );
}
