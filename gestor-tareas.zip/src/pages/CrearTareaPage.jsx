import { useForm } from "react-hook-form";
import { useEffect } from "react";

export default function CrearTareaPage() {
  const { register, handleSubmit, formState: { errors } } = useForm();

  useEffect(() => {
    document.title = "Crear Tarea - Gestor";
  }, []);

  const onSubmit = (data) => {
    console.log("Nueva tarea:", data);
    alert(`Tarea creada: ${data.titulo}`);
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">➕ Crear Nueva Tarea</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-3 max-w-md">
        <input
          {...register("titulo", { required: true })}
          placeholder="Escribe el título de la tarea..."
          className="border p-2 rounded"
        />
        {errors.titulo && <span className="text-red-600">Este campo es obligatorio.</span>}
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Guardar
        </button>
      </form>
    </div>
  );
}
